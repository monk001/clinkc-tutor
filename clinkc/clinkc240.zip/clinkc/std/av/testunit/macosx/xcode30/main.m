//
//  main.m
//  ClinkAVTestUnit
//
//  Created by ?? ? on 08/08/23.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
